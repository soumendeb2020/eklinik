<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class HomeController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index() {

        $department = DB::table('department')->select('department.*')->where('is_active', '=', 1)->get();
        //echo "<pre>"; print_r($department); exit;
        return view('home')->with(compact('department'));
    }

    public function getAddPatientResult() {
        //echo "<pre>"; print_r($_POST);  
        $searchby = $_POST['scat'];
        $searchname = $_POST['sdt'];
        $type = $_POST['stype'];

        if ($type == 'staffSection') {
            if ($searchby == 'sid') {
                $staff = DB::table('hr_maklumat_pekerjaan')->select('hr_maklumat_pekerjaan.*')->where('HR_NO_PEKERJA', '=', $searchname)->first();
                $det = DB::table('hr_maklumat_peribadi')->select('hr_maklumat_peribadi.*')->where('HR_NO_PEKERJA', '=', $searchname)->first();
            } else if ($searchby == 'ic') {
                $det = DB::table('hr_maklumat_peribadi')->select('hr_maklumat_peribadi.*')->where('HR_NO_KPBARU', '=', $searchname)->first();
                $staff = DB::table('hr_maklumat_pekerjaan')->select('hr_maklumat_pekerjaan.*')->where('HR_NO_PEKERJA', '=', $det->HR_NO_PEKERJA)->first();
            } else if ($searchby == 'name') {
                $det = DB::table('hr_maklumat_peribadi')->select('hr_maklumat_peribadi.*')->where('HR_NAMA_PEKERJA', '=', $searchname)->first();
                $staff = DB::table('hr_maklumat_pekerjaan')->select('hr_maklumat_pekerjaan.*')->where('HR_NO_PEKERJA', '=', $det->HR_NO_PEKERJA)->first();
            }
            $data['name'] = $det->HR_NAMA_PEKERJA;
            $data['staffid'] = $det->HR_NO_PEKERJA;
            $data['department'] = $staff->HR_JABATAN;
            $data['ic'] = $det->HR_NO_KPBARU;
            $data['dependent'] = '';
        } else if ($type == 'dependentSection') {
            if ($searchby == 'ic') {
                $det = DB::table('hr_maklumat_tanggungan')->select('hr_maklumat_tanggungan.*')->where('HR_NO_KP', '=', $searchname)->first();
            } else if ($searchby == 'name') {
                $det = DB::table('hr_maklumat_tanggungan')->select('hr_maklumat_tanggungan.*')->where('HR_NAMA_TANGGUNGAN', '=', $searchname)->first();
            }
            $data['name'] = $det->HR_NAMA_TANGGUNGAN;
            $data['staffid'] = $det->HR_NO_PEKERJA;
            $data['department'] = '';
            $data['ic'] = $det->HR_NO_KP;
            $data['dependent'] = '';
        } else if ($type == 'otherSection') {
            if ($searchby == 'ic') {
                $det = DB::table('patient')->select('patient.*')->where('ic_number', '=', $searchname)->first();
            } else if ($searchby == 'name') {
                $det = DB::table('patient')->select('patient.*')->where('name', '=', $searchname)->first();
            }
            $data['name'] = $det->name;
            $data['staffid'] = $det->staff_id;
            $data['department'] = $det->depart_name;
            $data['ic'] = $det->ic_number;
            $data['dependent'] = '';
        }
        return View('ajax.getAddPatientResult')->with(compact('data'));
    }

    public function getAddPatientResultdata() {
        //echo "<pre>"; print_r($_POST);  
        $searchby = $_POST['scat'];
        $searchname = $_POST['sdt'];
        $type = $_POST['stype'];

        if ($type == 'staffSection') {
            if ($searchby == 'sid') {
                $staff = DB::table('hr_maklumat_pekerjaan')->select('hr_maklumat_pekerjaan.*')->where('HR_NO_PEKERJA', '=', $searchname)->first();
                $det = DB::table('hr_maklumat_peribadi')->select('hr_maklumat_peribadi.*')->where('HR_NO_PEKERJA', '=', $searchname)->first();
            } else if ($searchby == 'ic') {
                $det = DB::table('hr_maklumat_peribadi')->select('hr_maklumat_peribadi.*')->where('HR_NO_KPBARU', '=', $searchname)->first();
                $staff = DB::table('hr_maklumat_pekerjaan')->select('hr_maklumat_pekerjaan.*')->where('HR_NO_PEKERJA', '=', $det->HR_NO_PEKERJA)->first();
            } else if ($searchby == 'name') {
                $det = DB::table('hr_maklumat_peribadi')->select('hr_maklumat_peribadi.*')->where('HR_NAMA_PEKERJA', '=', $searchname)->first();
                $staff = DB::table('hr_maklumat_pekerjaan')->select('hr_maklumat_pekerjaan.*')->where('HR_NO_PEKERJA', '=', $det->HR_NO_PEKERJA)->first();
            }
            $data['name'] = $det->HR_NAMA_PEKERJA;
            $data['staffid'] = $det->HR_NO_PEKERJA;
            $data['department'] = $staff->HR_JABATAN;
            $data['ic'] = $det->HR_NO_KPBARU;
            $data['dependent'] = '';
        } else if ($type == 'dependentSection') {
            if ($searchby == 'ic') {
                $det = DB::table('hr_maklumat_tanggungan')->select('hr_maklumat_tanggungan.*')->where('HR_NO_KP', '=', $searchname)->first();
            } else if ($searchby == 'name') {
                $det = DB::table('hr_maklumat_tanggungan')->select('hr_maklumat_tanggungan.*')->where('HR_NAMA_TANGGUNGAN', '=', $searchname)->first();
            }
            $data['name'] = $det->HR_NAMA_TANGGUNGAN;
            $data['staffid'] = $det->HR_NO_PEKERJA;
            $data['department'] = '';
            $data['ic'] = $det->HR_NO_KP;
            $data['dependent'] = '';
        } else if ($type == 'otherSection') {
            if ($searchby == 'ic') {
                $det = DB::table('patient')->select('patient.*')->where('ic_number', '=', $searchname)->first();
            } else if ($searchby == 'name') {
                $det = DB::table('patient')->select('patient.*')->where('name', '=', $searchname)->first();
            }
            $data['name'] = $det->name;
            $data['staffid'] = $det->staff_id;
            $data['department'] = $det->depart_name;
            $data['ic'] = $det->ic_number;
            $data['dependent'] = '';
        }
        return $data;
    }

    public function saveNewPatient() {
        //echo "<pre>";
        //print_r($_POST);
        ///    $_POST['staff_id']
        
        if($_POST['type'] == 'otherSection'){
            $typename = 'other';
        } else if($_POST['type'] == 'dependentSection'){
            $typename = 'dependent';
        } else if($_POST['type'] == 'staffSection'){
            $typename = 'staff';
        }
        
        $count = DB::table('patient')->count();
        $dept = DB::table('department')->select('department.*')->where('id', '=', $_POST['department_id'])->first();
        $savedata['staff_id'] = $_POST['staff_id'];      
        $savedata['ic_number'] = $_POST['ic_number'];
        $savedata['name'] = $_POST['name'];
        $savedata['symptopms'] = $_POST['symptopms'];
        $savedata['department_id'] = $_POST['department_id'];
        $savedata['depart_name'] = $dept->name;
        $savedata['type'] = $typename;
        $savedata['token_no'] = "C-".str_pad($count + 1, 5, '0', STR_PAD_LEFT);
        $savedata['created_time'] = date("h:i:s a", time());
        $savedata['created_at'] = date("Y-m-d h:i:s", time());
        $savedata['updated_at'] = date("Y-m-d h:i:s", time());

        if(DB::table('patient')->insert($savedata)){
            return $savedata;
        } else {
            return 0;
        }
        //exit;
    }

}
