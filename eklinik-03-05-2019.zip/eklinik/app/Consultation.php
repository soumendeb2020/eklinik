<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Authorizable;

class Consultation extends Model
{
    use Authorizable;
    //
}
