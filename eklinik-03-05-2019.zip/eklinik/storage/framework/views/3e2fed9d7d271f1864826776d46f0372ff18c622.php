<ol class="breadcrumb">
					<!-- <li>Home</li><li>Dashboard</li> -->
					<span class="badge badge-warning"><?php echo e(auth()->user()->roles->first()->name); ?>

							</span>
				</ol>